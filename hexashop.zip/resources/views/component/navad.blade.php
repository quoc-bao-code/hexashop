<nav>
    <ul>
        <li><a href="{{route('homead')}}">Trang Chủ</a></li>
        <li><a href="{{route('productad')}}">Sản phẩm</a></li>
        <li><a href="{{route('usersad')}}">Người dùng</a></li>
        <li><a href="{{route('home')}}">Trang User</a></li>
        <li><a href="{{route('logout')}}">Đăng xuất</a></li>
    </ul>
</nav>